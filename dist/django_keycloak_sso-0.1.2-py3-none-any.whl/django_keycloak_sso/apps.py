from django.apps import AppConfig

class DjangoKeyCloakSSOConfig(AppConfig):
    name = 'django_keycloak_sso'
    verbose_name = "Django KeyCloak SSO"
